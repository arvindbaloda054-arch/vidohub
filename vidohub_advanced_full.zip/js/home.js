
const grid=document.getElementById("videoGrid");
let videos=JSON.parse(localStorage.getItem("vhVideos")||"[]");

function render(){
  grid.innerHTML="";
  videos.forEach((v,i)=>{
    let c=document.createElement("a");
    c.className="card";
    c.href="watch.html?id="+i;
    c.innerHTML=`<img src="assets/thumb${(i%3)+1}.jpg"><div>${v.title}</div>`;
    grid.appendChild(c);
  });
}

document.addEventListener("DOMContentLoaded",()=>{ render(); });
