
document.getElementById("liveSend").onclick=()=>{
  let msg=document.getElementById("liveInput").value;
  if(!msg) return;
  let d=document.createElement("div");
  d.textContent=msg;
  document.getElementById("liveChat").appendChild(d);
  document.getElementById("liveInput").value="";
};
