
document.getElementById("adminSave").onclick=()=>{
  let t=document.getElementById("adminTitle").value;
  if(!t) return alert("Enter title");
  let videos=JSON.parse(localStorage.getItem("vhVideos")||"[]");
  videos.push({title:t,src:""});
  localStorage.setItem("vhVideos",JSON.stringify(videos));
  document.getElementById("adminMsg").textContent="Saved to homepage!";
};
