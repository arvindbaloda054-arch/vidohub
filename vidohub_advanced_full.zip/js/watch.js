
let id=new URLSearchParams(location.search).get("id");
let videos=JSON.parse(localStorage.getItem("vhVideos")||"[]");
let p=document.getElementById("videoPlayer");
let title=document.getElementById("vtitle");

if(videos[id]){
  title.textContent=videos[id].title;
  if(videos[id].src) p.src=videos[id].src;
}

document.getElementById("videoUpload").onchange=e=>{
  let f=e.target.files[0];
  p.src=URL.createObjectURL(f);
  title.textContent=f.name;
};

document.getElementById("playURL").onclick=()=>{
  let url=document.getElementById("videoURL").value;
  p.src=url;
  title.textContent=url.split("/").pop();
};

document.getElementById("commentSend").onclick=()=>{
  let c=document.getElementById("commentInput").value;
  if(!c) return;
  let box=document.createElement("div");
  box.textContent=c;
  document.getElementById("commentList").appendChild(box);
  document.getElementById("commentInput").value="";
};

document.getElementById("likeBtn").onclick=()=>alert("Liked!");
document.getElementById("subBtn").onclick=()=>alert("Subscribed!");
document.getElementById("followBtn").onclick=()=>alert("Following!");
document.getElementById("shareBtn").onclick=()=>navigator.clipboard.writeText(location.href);
